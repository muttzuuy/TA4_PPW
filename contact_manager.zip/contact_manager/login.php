<?php
include 'includes/helper.php';

$pageTitle = "Login Aplikasi Kontak";
$login_error = '';

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    $_SESSION['message'] = ['type' => 'success', 'text' => "Anda telah berhasil logout."];
    header("Location: login.php");
    exit();
}

if (is_logged_in()) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $clean_username = htmlspecialchars($username); 

    $user = authenticate_user($clean_username, $password);
    
    if ($user) {
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $user['username'];
        $_SESSION['message'] = ['type' => 'success', 'text' => "Selamat datang, **" . $user['username'] . "**! Anda berhasil login."];
        header("Location: index.php"); 
        exit();
    } else {
        $login_error = "Username atau Password salah! (Cek kembali kredensial atau daftar akun).";
    }
}

include 'includes/_header.php';

$flash_message = null;
if (isset($_SESSION['message'])) {
    $flash_message = $_SESSION['message'];
    unset($_SESSION['message']);
}

if ($flash_message) {
    $msg = $flash_message;
    echo "<div class='row justify-content-center'><div class='col-md-5 mt-4'>";
    echo "<div class='alert alert-{$msg['type']} alert-dismissible fade show' role='alert'>
            <i class='fas fa-info-circle me-1'></i> {$msg['text']}
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
          </div>";
    echo "</div></div>";
}

include 'views/auth/login.php'; 

include 'includes/_footer.php';
?>