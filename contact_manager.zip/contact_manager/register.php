<?php
include 'includes/helper.php';

if (is_logged_in()) {
    $_SESSION['message'] = ['type' => 'info', 'text' => "Anda sudah login sebagai " . htmlspecialchars($_SESSION['username']) . ". Silakan logout untuk mendaftar akun baru."];
    header("Location: index.php");
    exit();
}

$pageTitle = "Registrasi Akun Baru";
$register_error = '';
$form_data = ['username' => '', 'email' => ''];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input = filter_input_array(INPUT_POST, [
        'username' => FILTER_SANITIZE_STRING,
        'email' => FILTER_SANITIZE_EMAIL,
        'password' => FILTER_DEFAULT,
        'confirm_password' => FILTER_DEFAULT
    ]);

    $username = trim($input['username'] ?? '');
    $email = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';
    $confirm_password = $input['confirm_password'] ?? '';
    
    $form_data = ['username' => $username, 'email' => $email];
    
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $register_error = "Semua field harus diisi.";
    } 
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $register_error = "Format email tidak valid.";
    } 
    elseif (!preg_match("/^[a-zA-Z0-9_]{3,20}$/", $username)) {
        $register_error = "Username harus 3-20 karakter dan hanya boleh mengandung huruf, angka, atau underscore.";
    }

    elseif ($password !== $confirm_password) {
        $register_error = "Konfirmasi Password tidak cocok.";
    } 

    elseif (strlen($password) < 6) {
        $register_error = "Password minimal 6 karakter.";
    } 
    else {
        
        $data_user = [
            'username' => htmlspecialchars($username), 
            'email' => htmlspecialchars($email), 
            'password' => $password
        ];

        $result = register_user($data_user); 
        
        if ($result === true) {
            $_SESSION['message'] = ['type' => 'success', 'text' => "Registrasi berhasil! Akun **" . htmlspecialchars($username) . "** telah dibuat. Silakan Login."];
            header("Location: login.php");
            exit();
        } else {
            $register_error = $result; 
        }
    }
}

include 'includes/_header.php';
include 'views/auth/register.php'; 
include 'includes/_footer.php';
?>